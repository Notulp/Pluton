#!/bin/bash
mono ./Pluton.Patcher.exe --no-input > output.log
